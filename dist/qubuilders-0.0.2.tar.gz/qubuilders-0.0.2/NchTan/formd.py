
# this is the form that can be used to write json files
FORM = {
  "question_title": "",
  "answers": [],
  "choices": [],
  "hints": "",
  "descriptions": ""
}
