# QuBu
The qubu is an open source project that is created to help people 
especially teachers to make n choice questions with t answers faster
and quicly. The idea comes from the situation when you have a lot of questions that 
they all look to have the same pattern. Like these questions.

1-What is the simplified polynomial of the following polynomial?
5*x+3+7*x+5+23

2-What is the simplified polynomial of the following polynomial?
90*x+3+7*x+5+2

or 

1-how to say hello word in german?

2-how to say good word in german?

3-how to say hello word in Farsi?

...

they all look the same right?
the only different is this that some words and some numbers and
symbols are different, however the pattern, concept and the solution
of all of them is the same.

Now this is a little project named QuBu that will help you to generate
such questions.




